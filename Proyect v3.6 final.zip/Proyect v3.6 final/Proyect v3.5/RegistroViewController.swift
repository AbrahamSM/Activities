//
//  RegistroViewController.swift
//  Proyect v3.5
//
//  Created by macbookUser on 12/06/18.
//  Copyright © 2018 macbookUser. All rights reserved.
//

import UIKit

class RegistroViewController: UIViewController {
    
    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var correo: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var memberType: UITextField!
    
    var users: [User] = [
        User(firstname: "Victor", username: "vick", correo: "correo1@hotmail.com", password: "1234", tipoPersona: tipo(rawValue: 1)!),
        User(firstname: "Cesar", username: "ceteti", correo: "correo2@hotmail.com", password: "5678", tipoPersona: tipo(rawValue: 2)!),
        User(firstname: "Alfredo", username: "feyo", correo: "correo3@hotmail.com", password: "abcd", tipoPersona: tipo(rawValue: 3)!)
    ]
    

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white

    }
    
    @IBAction func login(_ sender: UIButton) {
        var validacion: Bool = true
        if let username = userName.text, let password = password.text{
            for user in users{
                if username == user.username, password == user.password{
                    print("Usuario confirmado y validado")
                    shouldPerformSegue(withIdentifier: "adelante", sender: self)
                    break
                }else{
                    validacion = false
                }
            }
        }
        if !validacion{
            showError()
        }
        userName.becomeFirstResponder()
        password.resignFirstResponder()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "adelante"{
            print("Ejecutando el segue Adelante")
            
        }
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if identifier == "adelante"{
            return true
        }else{
            return false
        }
    }
    
    func showError(){
        let errorAlert = UIAlertController(title: "Error", message: "Datos ingresados incorrectos", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
        errorAlert.addAction(okAction)
        present(errorAlert, animated: true, completion: nil)
    }
    
}
