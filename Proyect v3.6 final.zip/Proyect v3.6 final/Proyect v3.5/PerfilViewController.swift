//
//  PerfilViewController.swift
//  Proyect v3.5
//
//  Created by macbookUser on 13/06/18.
//  Copyright © 2018 macbookUser. All rights reserved.
//

import UIKit

class PerfilViewController: RegistroViewController {
    
    @IBOutlet weak var nombreUsuario: UILabel!
    @IBOutlet weak var email: UILabel!
    @IBOutlet weak var logo: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        logo.image = UIImage(named: "gm")
        
    }

}
