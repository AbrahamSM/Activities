//
//  SubirViewController.swift
//  Proyect v3.5
//
//  Created by macbookUser on 13/06/18.
//  Copyright © 2018 macbookUser. All rights reserved.
//

import UIKit

class SubirViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIDocumentBrowserViewControllerDelegate{
    
   // init(forOpeningFilesWithContentTypes:String)
    
    var delegate: UIDocumentBrowserViewControllerDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func buscar(_ sender: UIButton) {
    }


    
}

