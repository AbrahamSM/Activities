//
//  User.swift
//  Proyect v3.5
//
//  Created by macbookUser on 12/06/18.
//  Copyright © 2018 macbookUser. All rights reserved.
//

import Foundation
import UIKit

enum tipo: Int{
    case director = 1
    case consejero = 2
    case integrante = 3
}

struct User{
    var firstname: String
    var username: String
    var correo: String
    var password: String
    var tipoPersona: tipo
}
