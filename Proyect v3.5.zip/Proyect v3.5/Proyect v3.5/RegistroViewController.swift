//
//  RegistroViewController.swift
//  Proyect v3.5
//
//  Created by macbookUser on 12/06/18.
//  Copyright © 2018 macbookUser. All rights reserved.
//

import UIKit

class RegistroViewController: UIViewController {
    
    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var correo: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var memberType: UITextField!
    
    var users: [User] = [
        User(firstname: "Victor", correo: "correodejemplo1@hotmail.com", password: "1234", tipoPersona: "director"),
        User(firstname: "Cesar", correo: "correodejemplo2@hotmail.com", password: "5678", tipoPersona: "consejero"),
        User(firstname: "Alfredo", correo: "correodejemplo3@hotmail.com", password: "abcd", tipoPersona: "consejero"),
        User(firstname: "Christian", correo: "correodejemplo4@hotmail.com", password: "efgh", tipoPerosna: "integrante"),
        User(firstname: "Abraham", correo: "correodejemplo5@hotmail.com",  password: "9876", tipoPersona: "integrante")
    ]
    

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .blue

        // Do any additional setup after loading the view.
    }
    
    @IBAction func login(_ sender: UIButton) {
        var validacion: Bool = true
        if let username = userName.text, let correo = correo.text, let password = password.text, let tipoPersona = memberType.text{
            for user in users{
                if username == user.firstname, correo == user.correo, password == user.password, tipoPersona == user.tipoPersona{
                    print("Usuario confirmado y validado")
                    shouldPerformSegue(withIdentifier: "adelante", sender: self)
                }else{
                    validacion = false
                }
            }
        }
        if !validacion{
            showError()
        }
        userName.becomeFirstResponder()
        password.resignFirstResponder()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "adelante"{
            print("Ejecutando el segue Adelante")
            
        }
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if identifier == "adelante"{
            return true
        }else{
            return false
        }
    }
    
    func showError(){
        let errorAlert = UIAlertController(title: "Error", message: "Datos ingresados incorrectos", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
        errorAlert.addAction(okAction)
        present(errorAlert, animated: true, completion: nil)
    }
    
}
