//
//  User.swift
//  Proyect v3.5
//
//  Created by macbookUser on 12/06/18.
//  Copyright © 2018 macbookUser. All rights reserved.
//

import Foundation
import UIKit

enum tipo{
    case director
    case consejero
    case integrante
}

struct User{
    var firstname: String
    var correo: String
    var password: String
    var tipoPersona: tipo
}
