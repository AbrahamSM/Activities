//
//  SubirViewController.swift
//  Proyect v3.5
//
//  Created by macbookUser on 13/06/18.
//  Copyright © 2018 macbookUser. All rights reserved.
//

import UIKit

class SubirViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIDocumentBrowserViewControllerDelegate{
    
    var imageUpload = UIImage()
    
    let imageProfile: UIButton = {
        let bt = UIButton()
        bt.setImage(#imageLiteral(resourceName: "conquis"), for: .normal)
        bt.translatesAutoresizingMaskIntoConstraints = false
        bt.layer.cornerRadius = 50
        bt.layer.masksToBounds = true
        
        bt.addTarget(self, action: #selector(selectImage), for: .touchUpInside)
        return bt
    }()
    
    let uploadButton: UIButton = {
        let bt = UIButton()
        bt.backgroundColor = UIColor(red: 249/255, green: 167/255, blue: 74/255, alpha: 1.0)
        bt.translatesAutoresizingMaskIntoConstraints = false
        bt.setTitle("Guardar imagen", for: UIControlState())
        bt.setTitleColor(UIColor.black, for: UIControlState())
        bt.layer.cornerRadius = 5
        bt.layer.masksToBounds = true
        
        bt.addTarget(self, action: #selector(saveImage), for: .touchUpInside)
        return bt
    }()
    
    
    let myActivityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.gray)
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        print("---------------------------------------------")
        dump(info)
        print("---------------------------------------------")
        if let imagen = info["UIImagePickerControllerOriginalImage"] as? UIImage{
            imageProfile.setImage(imagen, for: .normal)
            imageUpload = imagen
            dismiss(animated: true, completion: nil)
        }
        
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        print("Cancelo el picker")
        dismiss(animated: true, completion: nil)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        view.addSubview(imageProfile)
        view.addSubview(uploadButton)
        view.addSubview(myActivityIndicator)
        
        
        imageProfile.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        imageProfile.topAnchor.constraint(equalTo: view.topAnchor, constant: 100).isActive = true
        imageProfile.heightAnchor.constraint(equalToConstant: 100).isActive = true
        imageProfile.widthAnchor.constraint(equalToConstant: 100).isActive = true
        
        uploadButton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        uploadButton.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        uploadButton.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -20).isActive = true
        uploadButton.heightAnchor.constraint(equalToConstant: 80).isActive = true
        
        myActivityIndicator.translatesAutoresizingMaskIntoConstraints = false
        myActivityIndicator.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        myActivityIndicator.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -100).isActive = true
        
    }
    
    @objc func selectImage(){
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        picker.allowsEditing = true
        present(picker, animated: true, completion: nil)
    }
    
    @objc func saveImage(){
        print("tratando de guardar datos")
        myActivityIndicator.startAnimating()
        
        let nombreImagen = UUID()
            print("se subio la imagen")
            self.myActivityIndicator.stopAnimating()
            
        }
}

