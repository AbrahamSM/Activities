//
//  ViewController.swift
//  Proyect v3.5
//
//  Created by macbookUser on 12/06/18.
//  Copyright © 2018 macbookUser. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var logo: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        logo.image = UIImage(named: "logoja")
        
        view.backgroundColor = .white
        
        // Do any additional setup after loading the view, typically from a nib.
    }


}

