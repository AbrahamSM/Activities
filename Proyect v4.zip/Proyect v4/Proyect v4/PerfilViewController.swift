//
//  PerfilViewController.swift
//  Proyect v4
//
//  Created by macbookUser on 14/06/18.
//  Copyright © 2018 macbookUser. All rights reserved.
//

import UIKit

class PerfilViewController: UIViewController {
    
    @IBOutlet weak var logo2: UIImageView!
    @IBOutlet weak var nombreUsuario: UILabel!
    @IBOutlet weak var correo1: UILabel!
    
    var info = ""
    var info2 = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        logo2.image = UIImage(named: "gm")

//        nombreUsuario.text = info
//        correo1.text = info2
        
    }

//    @IBAction func ir(_ sender: UIButton) {
//        shouldPerformSegue(withIdentifier: "ini", sender: self)
//    }
    
}
