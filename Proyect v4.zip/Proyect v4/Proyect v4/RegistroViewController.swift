//
//  RegistroViewController.swift
//  Proyect v4
//
//  Created by macbookUser on 14/06/18.
//  Copyright © 2018 macbookUser. All rights reserved.
//

import UIKit

class RegistroViewController: UIViewController {
    
    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var correo: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var memberType: UITextField!
    
    var users: [User] = [
        User(firstname: "Victor", username: "vick", correo: "correo1@hotmail.com", password: "1234", tipoPer: tipo(rawValue: 1)!),
        User(firstname: "Alfredo", username: "feyo", correo: "correo2@hotmail.com", password: "5678", tipoPer: tipo(rawValue: 2)!),
        User(firstname: "Cesar", username: "ceteti", correo: "correo3@hotmail.com", password: "0987", tipoPer: tipo(rawValue: 2)!),
        User(firstname: "Christian", username: "chris", correo: "correo4@hotmail.com", password: "6543", tipoPer: tipo(rawValue: 3)!),
        User(firstname: "Abraham", username: "abram", correo: "correo5@hotmail.com", password: "7117", tipoPer: tipo(rawValue: 3)!)
    ]
    

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .white
        
    }

    @IBAction func login(_ sender: UIButton) {
        var validacion: Bool = true
        if let Username = userName.text, let Password = password.text{
            for user in users{
                if Username == user.username, Password == user.password{
                    print("Usuario validado")
                    shouldPerformSegue(withIdentifier: "adelante", sender: self)
                    break
                }else{
                    validacion = false
                }
            }
        }
        if !validacion{
            showError()
        }
        userName.becomeFirstResponder()
        password.resignFirstResponder()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "adelante"{
            print("Ejecutando el segue adelante")
        }
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if identifier == "adelante"{
            return true
        }
        else{
            return false
        }
    }
    
    func showError(){
        let errorAlert = UIAlertController(title: "Error", message: "Sus datos no son correctos", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
        errorAlert.addAction(okAction)
        present(errorAlert, animated: true, completion: nil)
    }
}
