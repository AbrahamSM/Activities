//
//  ViewController.swift
//  Proyect v4
//
//  Created by macbookUser on 14/06/18.
//  Copyright © 2018 macbookUser. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imagen: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imagen.image = UIImage(named: "jalogo")
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    

}

