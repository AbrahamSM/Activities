//
//  User.swift
//  Proyect v4
//
//  Created by macbookUser on 14/06/18.
//  Copyright © 2018 macbookUser. All rights reserved.
//

import Foundation

enum tipo: Int{
    case director = 1
    case consejero = 2
    case integrante = 3
}

struct User{
    var firstname: String
    var username: String
    var correo: String
    var password: String
    var tipoPer: tipo
}
