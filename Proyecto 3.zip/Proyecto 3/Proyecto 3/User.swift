//
//  User.swift
//  Proyecto 3
//
//  Created by macbookUser on 11/06/18.
//  Copyright © 2018 macbookUser. All rights reserved.
//

import Foundation

enum tipo{
    case director
    case consejero
    case integrante
}

struct User{
    var firstname: String
    var correo: String
    var username: String
    var password: String
    var tipoPersona: tipo
}
