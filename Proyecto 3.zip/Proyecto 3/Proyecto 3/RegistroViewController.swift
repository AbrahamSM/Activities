//
//  RegistroViewController.swift
//  Proyecto 3
//
//  Created by macbookUser on 11/06/18.
//  Copyright © 2018 macbookUser. All rights reserved.
//

import UIKit

class RegistroViewController: UIViewController {
    
    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var correo: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var tipoMiembro: UITextField!
    

    var users: [User] = [
        User(firstname: "Victor", correo: "correodejemplo1@hotmail.com", username: "vick", password: "1234", tipoPersona: "director"),
        User(firstname: "Cesar", correo: "correodejemplo2@hotmail.com", username: "ceteti", password: "5678", tipoPersona: "consejero"),
        User(firstname: "Alfredo", correo: "correodejemplo3@hotmail.com", username: "feyo", password: "abcd", tipoPersona: "consejero"),
        User(firstname: "George", correo: "correodejemplo4@hotmail.com", username: "carburo", password: "efgh", tipoPerosna: "integrante"),
        User(firstname: "Antonio", correo: "correodejemplo5@hotmail.com", username: "tony", password: "9876", tipoPersona: "integrante"),
    ]

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .blue
        
        // Do any additional setup after loading the view.
    }

    @IBAction func ingresar(_ sender: UIButton) {
        var validacion: Bool = true
        if let username = userName.text, let correo = correo.text, let password = password.text{
            for user in users{
                if username == user.username, password == user.password, correo == user.correo{
                    print("Usuario confirmado y validado")
                    shouldPerformSegue(withIdentifier: "adelante", sender: self)
                    break
                }else{
                    validacion = false
                }
            }
        }
        
        if !validacion{
            showError()
        }
        
        userName.becomeFirstResponder()
        password.resignFirstResponder()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "adelante"{
            print("Ejecutando el segue Adelante")
            
        }
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if identifier == "adelante"{
            return true
        }else{
            return false
        }
    }
    
    func showError(){
        let errorAlert = UIAlertController(title: "Error", message: "Datos ingresados incorrectos", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
        
        errorAlert.addAction(okAction)
        
        present(errorAlert, animated: true, completion: nil)
    }
    
    
}
