//
//  ViewController.swift
//  Proyecto 3
//
//  Created by macbookUser on 11/06/18.
//  Copyright © 2018 macbookUser. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var logo: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        logo.image = UIImage(named: "JALogo")
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    

}

